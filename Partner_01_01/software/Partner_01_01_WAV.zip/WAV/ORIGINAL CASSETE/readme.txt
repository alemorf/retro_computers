﻿
Programs from the cassette # 5.960.002-01, 26.09.1989 for the PARTNER-01.01 computer, MSX format.
Loading
R<ВК>
/P<ВК>

----------------

The RKP folder contains the same programs, but converted in RK format. Loading
I<ВК>

For 02.rkp startup address is 0100, for the rest is initial load address.

----------------

01_TMGN - is not a program itself, but an array of data for tape player check.
